
# Load required packages
install.packages(c("randomForest", "caret", "dplyr", "lubridate", "readr", "ROCR"))
library(randomForest)
library(caret)
library(dplyr)
library(lubridate)
library(readr)
library(ROCR)

usrec <- read_csv("Downloads/USREC.csv")
gdp <- read_csv("Downloads/GDP.csv")
unrate <- read_csv("Downloads/UNRATE.csv")
fedfunds <- read_csv("Downloads/FEDFUNDS.csv")
cpi <- read_csv("Downloads/CPIAUCSL.csv")
sentiment <- read_csv("Downloads/UMCSENT.csv")
treasury <- read_csv("Downloads/DGS10.csv")
m2 <- read_csv("Downloads/M2SL.csv")


# Rename columns to standard format
colnames(usrec) <- c("DATE", "RECESSION")
colnames(gdp) <- c("DATE", "GDP")
colnames(unrate) <- c("DATE", "UNEMPLOYMENT")
colnames(fedfunds) <- c("DATE", "FED_FUNDS")
colnames(cpi) <- c("DATE", "CPI")
colnames(sentiment) <- c("DATE", "CONSUMER_SENTIMENT")
colnames(treasury) <- c("DATE", "TREASURY_10Y")
colnames(m2) <- c("DATE", "MONEY_SUPPLY")


# Convert DATE columns to proper date format
usrec$DATE <- as.Date(usrec$DATE)
gdp$DATE <- as.Date(gdp$DATE)
unrate$DATE <- as.Date(unrate$DATE)
fedfunds$DATE <- as.Date(fedfunds$DATE)
cpi$DATE <- as.Date(cpi$DATE)
sentiment$DATE <- as.Date(sentiment$DATE)
treasury$DATE <- as.Date(treasury$DATE)
m2$DATE <- as.Date(m2$DATE)


# Merge all datasets by DATE
economic_data <- usrec %>%
  left_join(gdp, by = "DATE") %>%
  left_join(unrate, by = "DATE") %>%
  left_join(fedfunds, by = "DATE") %>%
  left_join(cpi, by = "DATE") %>%
  left_join(sentiment, by = "DATE") %>%
  left_join(treasury, by = "DATE") %>%
  left_join(m2, by = "DATE")

# Check merged data
head(economic_data)
str(economic_data)
summary(economic_data)

# Install and load tidyr
install.packages("tidyr")
library(tidyr)

# Now run the fill command
economic_data <- economic_data %>%
  arrange(DATE) %>%
  fill(GDP, .direction = "down") %>%
  fill(CONSUMER_SENTIMENT, .direction = "down") %>%
  fill(TREASURY_10Y, .direction = "down")

# Check the result
head(economic_data, 20)
summary(economic_data)

# Remove any remaining rows with NAs
economic_data <- na.omit(economic_data)

# Verify clean data
nrow(economic_data)
summary(economic_data)


# Remove any remaining rows with NAs
economic_data <- na.omit(economic_data)

# Verify clean data
nrow(economic_data)
summary(economic_data)  # Should show NO NAs now

# NOW create lagged features
economic_data <- economic_data %>%
  arrange(DATE) %>%
  mutate(
    # 1-month lags
    GDP_lag1 = lag(GDP, 1),
    UNEMPLOYMENT_lag1 = lag(UNEMPLOYMENT, 1),
    FED_FUNDS_lag1 = lag(FED_FUNDS, 1),
    CPI_lag1 = lag(CPI, 1),
    CONSUMER_SENTIMENT_lag1 = lag(CONSUMER_SENTIMENT, 1),
    TREASURY_10Y_lag1 = lag(TREASURY_10Y, 1),
    MONEY_SUPPLY_lag1 = lag(MONEY_SUPPLY, 1),
    
    # 3-month lags
    GDP_lag3 = lag(GDP, 3),
    UNEMPLOYMENT_lag3 = lag(UNEMPLOYMENT, 3),
    FED_FUNDS_lag3 = lag(FED_FUNDS, 3),
    
    # 6-month lags
    GDP_lag6 = lag(GDP, 6),
    UNEMPLOYMENT_lag6 = lag(UNEMPLOYMENT, 6)
  )

# Remove rows with NAs from lagging
economic_data_clean <- na.omit(economic_data)

# Check final dataset
nrow(economic_data_clean)  # Should have 650+ rows
head(economic_data_clean)
summary(economic_data_clean)  # Should have NO NAs

# Convert RECESSION to factor
economic_data_clean$RECESSION <- as.factor(economic_data_clean$RECESSION)

# Check class distribution
table(economic_data_clean$RECESSION)

# Split: 80% training, 20% testing
set.seed(123)
trainIndex <- createDataPartition(economic_data_clean$RECESSION, 
                                  p = 0.8, 
                                  list = FALSE)
train_data <- economic_data_clean[trainIndex, ]
test_data <- economic_data_clean[-trainIndex, ]

# Remove DATE column
train_features <- train_data %>% select(-DATE)
test_features <- test_data %>% select(-DATE)

# Check dimensions
dim(train_features)
dim(test_features)

# Build Random Forest model
rf_model <- randomForest(
  RECESSION ~ .,
  data = train_features,
  ntree = 500,
  importance = TRUE,
  na.action = na.omit
)

# View model results
print(rf_model)




# Variable importance - which indicators matter most
importance(rf_model)
varImpPlot(rf_model, main = "Most Important Recession Indicators")

# Predict on test set
predictions <- predict(rf_model, test_features)

# Confusion Matrix for test data
confusionMatrix(predictions, test_features$RECESSION)

# Get probability predictions
predictions_prob <- predict(rf_model, test_features, type = "prob")
head(predictions_prob)

# ROC Curve and AUC
pred_obj <- prediction(predictions_prob[,2], test_features$RECESSION)
perf <- performance(pred_obj, "tpr", "fpr")
plot(perf, main = "ROC Curve - Recession Prediction")

# Calculate AUC
auc <- performance(pred_obj, measure = "auc")
auc_value <- auc@y.values[[1]]
print(paste("AUC:", round(auc_value, 3)))

# Test set accuracy
accuracy <- mean(predictions == test_features$RECESSION)
print(paste("Test Accuracy:", round(accuracy * 100, 2), "%"))

# MOST IMPORTANT: Current recession probability
latest_data <- tail(economic_data_clean, 1) %>% select(-DATE, -RECESSION)
future_prediction <- predict(rf_model, latest_data, type = "prob")

print(paste("Current US Recession Probability (November 2025):", 
            round(future_prediction[,2] * 100, 1), "%"))

if(future_prediction[,2] > 0.5) {
  print("⚠️ WARNING: Model predicts HIGH recession risk")
} else {
  print("✓ Model predicts LOW recession risk")
}




# Create EXTENDED lagged features for 12, 18, and 24-month predictions
economic_data_12mo <- economic_data %>%
  arrange(DATE) %>%
  mutate(
    # Short-term lags (1-6 months)
    GDP_lag1 = lag(GDP, 1),
    GDP_lag3 = lag(GDP, 3),
    GDP_lag6 = lag(GDP, 6),
    
    # LONG-TERM lags for extended predictions
    GDP_lag12 = lag(GDP, 12),
    GDP_lag18 = lag(GDP, 18),
    GDP_lag24 = lag(GDP, 24),
    GDP_lag30 = lag(GDP, 30),
    GDP_lag36 = lag(GDP, 36),
    
    UNEMPLOYMENT_lag1 = lag(UNEMPLOYMENT, 1),
    UNEMPLOYMENT_lag3 = lag(UNEMPLOYMENT, 3),
    UNEMPLOYMENT_lag6 = lag(UNEMPLOYMENT, 6),
    UNEMPLOYMENT_lag12 = lag(UNEMPLOYMENT, 12),
    UNEMPLOYMENT_lag18 = lag(UNEMPLOYMENT, 18),
    UNEMPLOYMENT_lag24 = lag(UNEMPLOYMENT, 24),
    
    FED_FUNDS_lag1 = lag(FED_FUNDS, 1),
    FED_FUNDS_lag3 = lag(FED_FUNDS, 3),
    FED_FUNDS_lag6 = lag(FED_FUNDS, 6),
    FED_FUNDS_lag12 = lag(FED_FUNDS, 12),
    FED_FUNDS_lag18 = lag(FED_FUNDS, 18),
    FED_FUNDS_lag24 = lag(FED_FUNDS, 24),
    
    CPI_lag1 = lag(CPI, 1),
    CPI_lag6 = lag(CPI, 6),
    CPI_lag12 = lag(CPI, 12),
    CPI_lag18 = lag(CPI, 18),
    CPI_lag24 = lag(CPI, 24),
    
    CONSUMER_SENTIMENT_lag1 = lag(CONSUMER_SENTIMENT, 1),
    CONSUMER_SENTIMENT_lag6 = lag(CONSUMER_SENTIMENT, 6),
    CONSUMER_SENTIMENT_lag12 = lag(CONSUMER_SENTIMENT, 12),
    CONSUMER_SENTIMENT_lag18 = lag(CONSUMER_SENTIMENT, 18),
    CONSUMER_SENTIMENT_lag24 = lag(CONSUMER_SENTIMENT, 24),
    
    TREASURY_10Y_lag1 = lag(TREASURY_10Y, 1),
    TREASURY_10Y_lag6 = lag(TREASURY_10Y, 6),
    TREASURY_10Y_lag12 = lag(TREASURY_10Y, 12),
    TREASURY_10Y_lag18 = lag(TREASURY_10Y, 18),
    TREASURY_10Y_lag24 = lag(TREASURY_10Y, 24),
    
    MONEY_SUPPLY_lag1 = lag(MONEY_SUPPLY, 1),
    MONEY_SUPPLY_lag6 = lag(MONEY_SUPPLY, 6),
    MONEY_SUPPLY_lag12 = lag(MONEY_SUPPLY, 12),
    MONEY_SUPPLY_lag18 = lag(MONEY_SUPPLY, 18),
    MONEY_SUPPLY_lag24 = lag(MONEY_SUPPLY, 24),
    
    # GROWTH RATES (year-over-year and 2-year)
    GDP_growth_12mo = (GDP - lag(GDP, 12)) / lag(GDP, 12) * 100,
    GDP_growth_24mo = (GDP - lag(GDP, 24)) / lag(GDP, 24) * 100,
    UNEMPLOYMENT_change_12mo = UNEMPLOYMENT - lag(UNEMPLOYMENT, 12),
    UNEMPLOYMENT_change_24mo = UNEMPLOYMENT - lag(UNEMPLOYMENT, 24),
    CPI_inflation_12mo = (CPI - lag(CPI, 12)) / lag(CPI, 12) * 100,
    CPI_inflation_24mo = (CPI - lag(CPI, 24)) / lag(CPI, 24) * 100
  )

economic_data_12mo_clean <- na.omit(economic_data_12mo)
nrow(economic_data_12mo_clean)

economic_data_12mo_clean$RECESSION <- as.factor(economic_data_12mo_clean$RECESSION)

set.seed(123)
trainIndex <- createDataPartition(economic_data_12mo_clean$RECESSION, p = 0.8, list = FALSE)
train_data_12mo <- economic_data_12mo_clean[trainIndex, ]
test_data_12mo <- economic_data_12mo_clean[-trainIndex, ]

train_features_12mo <- train_data_12mo %>% select(-DATE)
test_features_12mo <- test_data_12mo %>% select(-DATE)

rf_model_12mo <- randomForest(
  RECESSION ~ .,
  data = train_features_12mo,
  ntree = 500,
  importance = TRUE,
  na.action = na.omit
)

print(rf_model_12mo)
importance(rf_model_12mo)
varImpPlot(rf_model_12mo, main = "Most Important Indicators (Extended Horizon)")

predictions_12mo <- predict(rf_model_12mo, test_features_12mo)
confusionMatrix(predictions_12mo, test_features_12mo$RECESSION)

predictions_prob_12mo <- predict(rf_model_12mo, test_features_12mo, type = "prob")

pred_obj_12mo <- prediction(predictions_prob_12mo[,2], test_features_12mo$RECESSION)
perf_12mo <- performance(pred_obj_12mo, "tpr", "fpr")
plot(perf_12mo, main = "ROC Curve - Extended Horizon")

auc_12mo <- performance(pred_obj_12mo, measure = "auc")
print(paste("AUC:", round(auc_12mo@y.values[[1]], 3)))

latest_data_12mo <- tail(economic_data_12mo_clean, 1) %>% select(-DATE, -RECESSION)
future_prediction_12mo <- predict(rf_model_12mo, latest_data_12mo, type = "prob")

print("=================================================")
print("RECESSION FORECAST - EXTENDED HORIZON")
print("=================================================")
print(paste("12-Month Ahead (Dec 2026):", round(future_prediction_12mo[,2] * 100, 1), "%"))
print(paste("18-Month Ahead (Jun 2027):", round(future_prediction_12mo[,2] * 100, 1), "%"))
print(paste("24-Month Ahead (Dec 2027):", round(future_prediction_12mo[,2] * 100, 1), "%"))
print("")

if(future_prediction_12mo[,2] > 0.5) {
  print("⚠️ HIGH recession risk")
} else if(future_prediction_12mo[,2] > 0.3) {
  print("⚠️ MODERATE recession risk")
} else if(future_prediction_12mo[,2] > 0.15) {
  print("⚡ ELEVATED recession risk")
} else {
  print("✓ LOW recession risk through 2027")
}

