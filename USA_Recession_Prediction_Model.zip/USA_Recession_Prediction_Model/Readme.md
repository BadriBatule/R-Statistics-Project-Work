# **US Recession Prediction with Random Forest** 

This project builds and evaluates Random Forest models in R to predict US recessions using macroeconomic time series data from 1970–2025.

## **Project Overview**

We combined key US macro indicators from FRED (Federal Reserve Economic Data) with the NBER recession indicator and trained classification models to estimate recession probabilities over different horizons.

The work includes:

* Data collection and merging of monthly series

* Feature engineering with multiple time lags and growth rates

* Short-horizon (1–6 months ahead) Random Forest model

* Extended-horizon (12–24+ months ahead) Random Forest model

* Model evaluation (accuracy, AUC, confusion matrices)

* Variable importance analysis

* Recession probability forecasts through 2027\.

## **Data**

Core series (monthly) sourced from FRED:

* USREC: NBER recession indicator (0 \= no recession, 1 \= recession)

* GDP: Gross Domestic Product (real/nominal series aligned to monthly frequency)

* UNRATE: Unemployment rate

* FEDFUNDS: Federal Funds rate (monetary policy)

* CPIAUCSL: Consumer Price Index (inflation)

* UMCSENT: Consumer sentiment index (confidence)

* DGS10: 10-year Treasury yield (long-term rates)

* M2SL: Money supply (M2)

After merging by DATE, we engineered:

* Short lags: 1, 3, 6 months

* Long lags: 12, 18, 24, 30, 36 months

* Year-over-year and two-year changes:

  * GDP\_growth\_12mo, GDP\_growth\_24mo

  * UNEMPLOYMENT\_change\_12mo, UNEMPLOYMENT\_change\_24mo

  * CPI\_inflation\_12mo, CPI\_inflation\_24mo.

Rows with missing values created by lagging were dropped, leaving \~630 monthly observations for modeling.

## **Models**

## **1\. Short-Term Recession Model (1–6 Months Ahead)**

* Algorithm: Random Forest (classification, 500 trees)

* Input features: Current and lagged (1, 3, 6-month) values of all indicators

* Target: RECESSION (0/1) for the current/next month

* Train/test split: 80% / 20%.

**Performance (test set)**:

* Accuracy: **96.97%**

* AUC: **0.98** (excellent discrimination)

* Sensitivity (non-recession class): 0.99

* Specificity (recession class): 0.80

**Most important short-term predictors** (MeanDecreaseAccuracy):

* Consumer sentiment (current and 1-month lag)

* Federal Funds rate (3-month lag)

* Money supply (current and lagged)

* Unemployment rate (6-month lag)

Interpretation: For near-term forecasts, **consumer psychology and recent monetary policy** shifts dominate recession risk.

## **2\. Extended-Horizon Model (12–24+ Months Ahead)**

* Algorithm: Random Forest (500 trees)

* Features: All short-term lags plus 12, 18, 24, 30, 36-month lags and 12–24 month growth rates

* Target: RECESSION (0/1) at the horizon month

* Same 80/20 train/test split.

**Performance (test set)**:

* Accuracy: **96.8%**

* AUC: **0.997** (near-perfect)

* Balanced accuracy: \~0.92

**Most important long-term predictors**:

* 12‑month change in unemployment

* 12‑month GDP growth

* Consumer sentiment (current and lagged)

* 6‑month lag of Federal Funds rate

* 24‑month change in unemployment

* 12‑month CPI inflation.

Interpretation: Over 1–2 years, **labor market trends and growth momentum** drive recession risk more than short-term sentiment alone.

## **Key Results**

## **Current and Near-Term Outlook (as of latest data \~Nov 2025\)**

* Short-term recession probability: **0.2%** for the next 1–3 months.

* Interpretation: **Very low risk** of an imminent US recession based on current macro conditions and model signals.

## **12–24 Month Outlook**

From the extended-horizon model using latest available data:

* **12‑month ahead (Dec 2026\)**: 2.4% recession probability

* **18‑month ahead (Jun 2027\)**: 2.4%

* **24‑month ahead (Dec 2027\)**: 2.4%

All values fall in a **“low risk”** band (\<15%) by the project’s thresholds, suggesting a high likelihood that the US avoids recession through 2027 under current trends.

## **How to Run**

1. Download monthly CSVs for all eight FRED series and USREC (recession indicator) from FRED.

2. Place them in a working directory and read them into R, converting DATE to Date.

3. Merge series by DATE and apply forward-filling for lower-frequency series (e.g., quarterly GDP) as needed.

4. Use the provided script to:

   * Create lagged and growth features

   * Clean missing values

   * Split into train/test sets

   * Fit Random Forest models

   * Evaluate accuracy, AUC, variable importance

   * Generate recession probability forecasts for chosen horizons.

## **Interpretation Caveats**

* The models are **probabilistic**, not deterministic; they estimate risk given historical patterns and current indicators.

* They assume **structural stability**: if policy shocks or events occur that have no historical analogue (e.g., extreme trade wars, geopolitical crises), forecasts may be less reliable.

* Recessions are **rare events**, so even high-accuracy models can miss some episodes; monitoring updated data and re‑training regularly is essential.

## **Repository Contents (Suggested)**

* data/ – Raw FRED CSVs (USREC, GDP, UNRATE, FEDFUNDS, CPIAUCSL, UMCSENT, DGS10, M2SL)

* scripts/

  * 01\_merge\_and\_clean.R – Merging and preprocessing

  * 02\_random\_forest\_short\_term.R – 1–6 month model

  * 03\_random\_forest\_extended\_horizon.R – 12–24+ month model

* figures/ – Variable importance plots and ROC curves for both models.

* README.md – This document.

This project shows how Random Forests and macroeconomic time series can be combined in R to produce **transparent, interpretable recession risk estimates** for the US economy.

