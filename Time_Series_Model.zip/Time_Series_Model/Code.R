# TIME SERIES DEMAND FORECASTING - COMPLETE R PIPELINE

# This script:
# 1. Generates or loads time series data
# 2. Engineers lag and seasonal features
# 3. Trains 4 different ML models
# 4. Evaluates and selects the best model
# 5. Generates 12-period forecast with confidence intervals
# 6. Creates professional visualizations



# SETUP: Install and Load Required Packages

# Install packages (run once)
# install.packages(c("tidyverse", "caret", "forecast", "ggplot2", "scales", "gbm", "kernlab"))

# Load libraries
library(tidyverse)
library(caret)
library(forecast)
library(ggplot2)
library(scales)

cat("\n")
cat("=\n")
cat("DEMAND FORECASTING SYSTEM - R VERSION\n")
cat("=\n")


# STEP 1: DATA GENERATION OR LOADING

cat("\n[1/6] Generating Data\n")

# Option A: Generate synthetic data (for demo)
set.seed(42)
n_periods <- 100

demand_data <- tibble(
  period = 1:n_periods,
  date = seq(as.Date("2020-01-01"), by = "month", length.out = n_periods),
  # Trend component
  trend = 100 + 0.5 * period,
  # Seasonal component (12-month cycle)
  seasonal = 20 * sin(2 * pi * period / 12),
  # Noise component
  noise = rnorm(n_periods, 0, 10),
  # Combine all components
  demand = trend + seasonal + noise
) %>%
  mutate(demand = pmax(demand, 0))  # Ensure non-negative

# Option B: Load your own CSV (uncomment and modify)
# demand_data <- read_csv("data/your_file.csv") %>%
#   mutate(
#     date = as.Date(date),
#     period = row_number()
#   ) %>%
#   select(period, date, demand)

cat("✓ Generated", nrow(demand_data), "periods of demand data\n")
cat("  Date range:", format(min(demand_data$date), "%Y-%m-%d"), 
    "to", format(max(demand_data$date), "%Y-%m-%d"), "\n")


# STEP 2: TRAIN-TEST SPLIT
split_index <- round(0.8 * nrow(demand_data))
train_data <- demand_data %>% slice(1:split_index)
test_data <- demand_data %>% slice((split_index + 1):nrow(demand_data))

cat("✓ Train-test split:", nrow(train_data), "train /", nrow(test_data), "test\n")


# STEP 3: FEATURE ENGINEERING
cat("\n[2/6] Engineering Features\n")

create_lag_features <- function(data, lag_periods = 12) {
  # Create lag features
  lags_matrix <- matrix(NA, nrow = nrow(data), ncol = lag_periods)
  
  for (i in 1:lag_periods) {
    lags_matrix[, i] <- c(rep(NA, i), data$demand[1:(nrow(data) - i)])
  }
  
  colnames(lags_matrix) <- paste0("lag_", 1:lag_periods)
  
  # Add additional features
  data %>%
    mutate(
      # Trend feature
      trend_feature = row_number(),
      # Seasonal feature
      seasonal_feature = period %% 12
    ) %>%
    bind_cols(as_tibble(lags_matrix)) %>%
    # Remove rows with NAs from lags
    drop_na()
}

train_features <- create_lag_features(train_data)
test_features <- create_lag_features(test_data)

cat("✓ Lag features created:", 12, "lags per sample\n")

# Prepare model data (CONVERT TO DATA.FRAME to avoid warnings)
X_train <- train_features %>% 
  select(starts_with("lag"), trend_feature, seasonal_feature) %>%
  as.data.frame()

y_train <- train_features$demand

X_test <- test_features %>% 
  select(starts_with("lag"), trend_feature, seasonal_feature) %>%
  as.data.frame()

y_test <- test_features$demand

cat("✓ Training samples:", nrow(X_train), "\n")
cat("✓ Test samples:", nrow(X_test), "\n")
cat("✓ Features per sample:", ncol(X_train), "\n")


# STEP 4: TRAIN MODELS
cat("\n[3/6] Training Models\n")

# Control for cross-validation
control <- trainControl(
  method = "timeslice",
  initialWindow = nrow(X_train) - 20,
  horizon = 10,
  fixedWindow = TRUE,
  savePredictions = TRUE
)

# Model 1: Random Forest
cat("Training Random Forest...\n")
model_rf <- train(
  y = y_train,
  x = X_train,
  method = "rf",
  trControl = control,
  ntree = 100,
  tuneLength = 1,
  verbose = FALSE
)
cat("✓ Random Forest trained\n")

# Model 2: Gradient Boosting
cat("Training Gradient Boosting...\n")
model_gbm <- train(
  y = y_train,
  x = X_train,
  method = "gbm",
  trControl = control,
  tuneLength = 1,
  verbose = FALSE
)
cat("✓ Gradient Boosting trained\n")

# Model 3: Linear Regression
cat("Training Linear Regression...\n")
model_lm <- train(
  y = y_train,
  x = X_train,
  method = "lm",
  trControl = control
)
cat("✓ Linear Regression trained\n")

# Model 4: Support Vector Regression
cat("Training SVM...\n")
model_svr <- train(
  y = y_train,
  x = X_train,
  method = "svmRadial",
  trControl = control,
  tuneLength = 1,
  verbose = FALSE
)
cat("✓ SVM trained\n")

cat("✓ All models trained successfully!\n")


# STEP 5: EVALUATE MODELS
cat("\n[4/6] Evaluating Models\n")

# Function to calculate metrics
calc_metrics <- function(actual, predicted) {
  mae <- mean(abs(actual - predicted))
  rmse <- sqrt(mean((actual - predicted)^2))
  ss_res <- sum((actual - predicted)^2)
  ss_tot <- sum((actual - mean(actual))^2)
  r2 <- 1 - (ss_res / ss_tot)
  mape <- mean(abs((actual - predicted) / actual)) * 100
  
  list(MAE = mae, RMSE = rmse, R2 = r2, MAPE = mape)
}

# Get predictions
pred_rf <- predict(model_rf, X_test)
pred_gbm <- predict(model_gbm, X_test)
pred_lm <- predict(model_lm, X_test)
pred_svr <- predict(model_svr, X_test)

# Calculate metrics
metrics <- tibble(
  Model = c("Random Forest", "Gradient Boosting", "Linear Regression", "SVM"),
  MAE = c(
    calc_metrics(y_test, pred_rf)$MAE,
    calc_metrics(y_test, pred_gbm)$MAE,
    calc_metrics(y_test, pred_lm)$MAE,
    calc_metrics(y_test, pred_svr)$MAE
  ),
  RMSE = c(
    calc_metrics(y_test, pred_rf)$RMSE,
    calc_metrics(y_test, pred_gbm)$RMSE,
    calc_metrics(y_test, pred_lm)$RMSE,
    calc_metrics(y_test, pred_svr)$RMSE
  ),
  R2 = c(
    calc_metrics(y_test, pred_rf)$R2,
    calc_metrics(y_test, pred_gbm)$R2,
    calc_metrics(y_test, pred_lm)$R2,
    calc_metrics(y_test, pred_svr)$R2
  ),
  MAPE = c(
    calc_metrics(y_test, pred_rf)$MAPE,
    calc_metrics(y_test, pred_gbm)$MAPE,
    calc_metrics(y_test, pred_lm)$MAPE,
    calc_metrics(y_test, pred_svr)$MAPE
  )
)

cat("\n")
cat("=\n")
cat("MODEL PERFORMANCE COMPARISON\n")
cat("=\n")
print(metrics %>% arrange(desc(R2)))

# Select best model
best_model_info <- metrics %>% slice_max(R2)
best_model_name <- best_model_info$Model

# Use switch for cleaner model selection
best_model <- switch(best_model_name,
                     "Random Forest" = model_rf,
                     "Gradient Boosting" = model_gbm,
                     "Linear Regression" = model_lm,
                     "SVM" = model_svr,
                     model_rf  # default
)

cat("\n✓ Best Model:", best_model_name, "\n")
cat("  R² Score:", round(best_model_info$R2, 4), "\n")
cat("  MAE:", round(best_model_info$MAE, 2), "\n")
cat("  RMSE:", round(best_model_info$RMSE, 2), "\n")


# STEP 6: GENERATE FORECASTS
cat("\n[5/6] Generating Forecasts\n")

# Calculate residual standard error for confidence intervals
residuals <- y_test - predict(best_model, X_test)
std_error <- sd(residuals)
z_score <- 1.96  # 95% confidence

n_forecast <- 12
forecasts <- numeric(n_forecast)
forecast_lower <- numeric(n_forecast)
forecast_upper <- numeric(n_forecast)

# Start with last features from test set
last_features <- X_test %>% tail(1)

# Recursive forecasting
for (i in 1:n_forecast) {
  # Predict next value
  next_pred <- predict(best_model, last_features)[1]
  forecasts[i] <- next_pred
  forecast_lower[i] <- next_pred - (z_score * std_error)
  forecast_upper[i] <- next_pred + (z_score * std_error)
  
  # Update features for next iteration
  last_features <- last_features %>%
    select(-lag_1) %>%
    rename_with(~paste0("lag_", as.numeric(gsub("lag_", "", .)) + 1), starts_with("lag_")) %>%
    mutate(lag_1 = next_pred)
}

forecast_df <- tibble(
  period = 1:n_forecast,
  forecast = forecasts,
  lower_95 = forecast_lower,
  upper_95 = forecast_upper
)

cat("✓ 12-period forecast generated\n\n")
cat("=\n")
cat("FORECAST: NEXT 12 PERIODS\n")
cat("=\n")
print(forecast_df)


# STEP 7: CREATE VISUALIZATIONS
cat("\n[6/6] Creating Visualizations\n")

# Plot 1: Actual vs Predicted
p1 <- ggplot() +
  geom_line(data = train_data, aes(x = date, y = demand, color = "Training"), linewidth = 1) +
  geom_line(data = test_data, aes(x = date, y = demand, color = "Actual"), linewidth = 1) +
  geom_line(
    data = test_features %>% mutate(pred = predict(best_model, X_test), date = test_data$date[1:length(pred)]),
    aes(x = date, y = pred, color = "Predicted"),
    linetype = "dashed", linewidth = 1
  ) +
  scale_color_manual(values = c("Training" = "#217F8D", "Actual" = "#217F8D", "Predicted" = "#32B8C6")) +
  labs(title = "Actual vs Predicted Demand",
       subtitle = paste("Best Model:", best_model_name),
       x = "Date", y = "Demand Units",
       color = "Legend") +
  theme_minimal() +
  theme(legend.position = "top", plot.title = element_text(face = "bold", size = 14))

# Plot 2: Forecast with CI
p2 <- ggplot(forecast_df, aes(x = period, y = forecast)) +
  geom_ribbon(aes(ymin = lower_95, ymax = upper_95), alpha = 0.2, fill = "#E67E22") +
  geom_line(color = "#1A6A73", linewidth = 1.2) +
  geom_point(color = "#1A6A73", size = 3) +
  labs(title = "Forecast with 95% Confidence Interval",
       subtitle = paste("Next", n_forecast, "periods"),
       x = "Forecast Period", y = "Demand Units") +
  theme_minimal() +
  theme(plot.title = element_text(face = "bold", size = 14))

# Plot 3: Residuals Distribution
residuals_df <- tibble(
  actual = y_test,
  predicted = predict(best_model, X_test),
  residual = actual - predicted
)

p3 <- ggplot(residuals_df, aes(x = residual)) +
  geom_histogram(bins = 20, fill = "#217F8D", color = "white", alpha = 0.7) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "#C0152F", linewidth = 1) +
  labs(title = "Residuals Distribution",
       subtitle = paste("Mean:", round(mean(residuals_df$residual), 2)),
       x = "Residual Value", y = "Frequency") +
  theme_minimal() +
  theme(plot.title = element_text(face = "bold", size = 14))

# Plot 4: Model Comparison
p4 <- metrics %>%
  pivot_longer(cols = c("MAE", "RMSE", "R2", "MAPE"),
               names_to = "Metric", values_to = "Value") %>%
  ggplot(aes(x = Model, y = Value, fill = Model)) +
  geom_col(alpha = 0.7) +
  facet_wrap(~Metric, scales = "free_y") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        plot.title = element_text(face = "bold", size = 14),
        legend.position = "none") +
  labs(title = "Model Performance Comparison")

# Display plots
print(p1)
print(p2)
print(p3)
print(p4)

cat("✓ Visualizations created\n")


# SUMMARY
cat("\n")
cat("=\n")
cat("FORECAST SUMMARY\n")
cat("=\n")
cat("\nTotal Forecasted Demand (", n_forecast, " periods):", round(sum(forecast_df$forecast), 0), "units\n")
cat("Average per Period:", round(mean(forecast_df$forecast), 2), "units\n")
cat("Range:", round(min(forecast_df$forecast), 2), "-", 
    round(max(forecast_df$forecast), 2), "units\n")
cat("\n95% Confidence Interval:\n")
cat("  Lower Bound Range:", round(min(forecast_df$lower_95), 2), "-", 
    round(max(forecast_df$lower_95), 2), "units\n")
cat("  Upper Bound Range:", round(min(forecast_df$upper_95), 2), "-", 
    round(max(forecast_df$upper_95), 2), "units\n")

cat("\n")
cat("=\n")
cat("✓ PIPELINE COMPLETE!\n")
cat("=\n")
cat("\nNext Steps:\n")
cat("  1. Review the plots in the Plots pane\n")
cat("  2. Check forecast_df for detailed predictions\n")
cat("  3. Use metrics table to understand model performance\n")
cat("  4. Save plots: ggsave('forecast.png', p2, width=10, height=6)\n")
cat("  5. Export forecast: write_csv(forecast_df, 'forecast_results.csv')\n")
cat("\n")

