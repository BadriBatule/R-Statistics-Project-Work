# Time Series Forecasting with R (Any Demand / Volume Series)

This project is a **simple, end‑to‑end forecasting pipeline in R**. You can plug in **any time series** (monthly, weekly, daily, etc.) and get:

- A **12‑step‑ahead forecast**  
- **95% confidence intervals**  
- **Model comparison** across four ML algorithms  
- Clean **ggplot2 visualizations**

The example code uses synthetic data, but you can easily replace it with your own series such as:

- Drug prescriptions per month  
- Clinical trial enrollments per month  
- Sales volume per week  
- Bed occupancy per day  
- Website signups per day

---

## 1\. What this project does

For a given time series with a `date` and a numeric `demand` column, the script:

1. **Loads data**  
2. **Builds features** (lags, trend, seasonality)  
3. **Trains 4 models** using `caret`:  
   - Random Forest  
   - Gradient Boosting (`gbm`)  
   - Support Vector Regression (`svmRadial`)  
   - Linear Regression (baseline)  
4. **Evaluates all models** on a test set  
5. **Chooses the best model** based on error metrics  
6. **Forecasts the next 12 periods**  
7. **Draws plots**:  
   - Actual vs Predicted  
   - Forecast with 95% Confidence Interval  
   - Residuals Distribution  
   - Model Performance Comparison

---

## 2\. Folder / file structure

A minimal setup might look like:

.

├── demand\_forecast\_R.R        \# Main R script (full pipeline)

├── data/

│   └── my\_series.csv          \# Your own time series (optional)

└── README.md                  \# This file

You can rename `demand_forecast_R.R` however you like.

---

## 3\. Requirements

- R (4.x recommended)  
- Suggested IDE: RStudio

Packages used:

  "tidyverse",  \# data handling \+ ggplot2

  "caret",      \# machine learning framework

  "forecast",   \# time series tools (optional here)

  "gbm",        \# gradient boosting model

  "kernlab",    \# SVM backend

  "scales"      \# nicer axis formatting

---

## 4\. Quick start (run the demo)

1. Open R or RStudio in this project folder  
2. Install packages (first time only):

install.packages(c("tidyverse", "caret", "forecast", "gbm", "kernlab", "scales"))

3. Run the script:

source("demand\_forecast\_R.R")

You should see in the console:

- Messages like “Training Random Forest…”, “All models trained successfully\!”  
- A **model performance table**  
- A **12‑period forecast table** with lower / upper bounds  
- Several plots in the Plot pane:  
  - Actual vs Predicted Demand  
  - Forecast with 95% Confidence Interval  
  - Residuals Distribution  
  - Model Performance Comparison

---

## 5\. Using your own time series

To use your own data instead of the synthetic example:

1. Put your CSV file in `data/`, for example:

data/my\_series.csv

2. Your CSV should have at least:  
- A **date column** (any format R can parse with `as.Date`)  
- A **numeric column** that you want to forecast (here called `demand`)

Example:

date,demand

2020-01-31,120

2020-02-29,135

2020-03-31,140

3. In the script, replace the synthetic data block:

 \--- original synthetic data block (remove or comment this) \---

set.seed(42)

n\_periods \<- 100

demand\_data \<- tibble(

  period \= 1:n\_periods,

  date   \= seq(as.Date("2020-01-01"), by \= "month", length.out \= n\_periods),

  trend  \= 100 \+ 0.5 \* period,

  seasonal \= 20 \* sin(2 \* pi \* period / 12),

  noise  \= rnorm(n\_periods, 0, 10),

  demand \= trend \+ seasonal \+ noise

) %\>%

  mutate(demand \= pmax(demand, 0))

with something like:

\# \--- load your real data here \---

library(readr)

demand\_data \<- read\_csv("data/my\_series.csv") %\>%

  mutate(

    date   \= as.Date(date),

    period \= dplyr::row\_number()

  ) %\>%

  dplyr::select(period, date, demand)

4. Leave the rest of the script unchanged. It will:  
   - Split your data into train/test  
   - Engineer lag / trend / seasonal features  
   - Train 4 models  
   - Pick the best one  
   - Forecast the next 12 periods

---

## 6\. How to read the outputs

### Model performance table

You will see something like:

\# A tibble: 4 × 5

  Model                      MAE  RMSE    R2  MAPE

1 Gradient Boosting  12.5  15.7     0.62   8.0

2 Random Forest      14.0  18.2     0.55   9.5

3 SVM                       16.3  19.0     0.50  10.2

4 Linear Regression  30.0  35.0     0.10  18.0

- **MAE / RMSE** – smaller is better (smaller errors)  
- **MAPE** – average percentage error  
- **R²** – higher is better (1 \= perfect, 0 \= bad, negative \= worse than using the mean)

The script chooses the model with the best R² / lowest error and calls it `best_model`.

### Forecast table

Example:

\# A tibble: 12 × 4

period forecast lower\_95 upper\_95

 1      1     145\.     120\.     169\.

 2      2     138\.     113\.     162\.  
…

12     12     105\.      81\.     130\.

This means:

- For the **next 12 periods**:  
  - `forecast` is the model’s best guess  
  - `lower_95` and `upper_95` give a **95% confidence range**

You can use this to:

- Plan inventory / capacity  
- Estimate revenue or volume  
- Communicate “most likely” and “best/worst” cases

### Plots

- **Actual vs Predicted Demand** Shows how closely the model follows your historical data.  
- **Forecast with 95% Confidence Interval** Dark line \= forecast; shaded area \= uncertainty band.  
- **Residuals Distribution** Shows how big the errors are and whether they are centered around zero.  
- **Model Performance Comparison** Bar charts comparing MAE, RMSE, R², MAPE across the four models.

---

## 7\. Typical use cases

Because the code only assumes a `date` and `demand` column, you can use it for:

- Drug prescriptions per month  
- Clinical trial patient enrollment  
- Hospital admissions or ICU beds per day  
- Product sales per week or month  
- Call center volumes  
- Website visits or signups

Anywhere you have a **time‑stamped numeric series**, you can:

1. Drop your data into `data/my_series.csv`  
2. Update the load section  
3. Run `source("demand_forecast_R.R")`  
4. Get forecasts \+ plots

---

## 8\. Notes / limitations

- This is a **univariate** forecaster (uses past values of the series itself). You can extend it with external features (price, campaigns, etc.) by adding columns to `X_train` / `X_test`.  
- Performance depends heavily on data quality and the stability of the underlying process.  
- The default forecast horizon is **12 steps**; you can change `n_forecast` in the script.

---

## 9\. License

Add whatever license you prefer, for example:

MIT License

Copyright (c) 2026 Your Name  
