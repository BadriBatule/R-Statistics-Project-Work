# Basic-Stat-with-R

A collection of fundamental statistical methods in R with practical examples.

Datasets Used
swiss: Swiss fertility and socioeconomic indicators (47 observations)

iris: Iris flower measurements across 3 species (150 observations)

binary.csv: Graduate school admission data (400 observations)

Methods
1. Linear Regression
Tests relationships between variables and predicts outcomes. Checks for multicollinearity using VIF.

Result: Fertility significantly predicts infant mortality (p = 0.007)

2. ANOVA
Compares means across multiple groups to test if differences are significant.

Result: Sepal width differs significantly across iris species (p < 0.001)

3. K-Means Clustering
Groups observations based on similarity without predefined labels.

Result: 3 clusters identified, works well for setosa species only

4. Logistic Regression
Predicts binary outcomes (yes/no) and evaluates model performance with ROC/AUC.

Result: Model achieves 69.5% accuracy, AUC = 0.63 (poor performance)

Packages Required
r
datasets, ggplot2, car, caret, NbClust, pscl, ROCR, zeallot
Usage
Run script sequentially in RStudio. Each section demonstrates model building, diagnostics, and evaluation.
