
# Statistics Basics 

require(datasets)
require(ggplot2)
data(swiss)
str(swiss)
summary(swiss)


# see whether it follows normal distribution
hist(swiss$Infant.Mortality)
qqnorm(swiss$Infant.Mortality)
qqline(swiss$Infant.Mortality)

model<-lm(Infant.Mortality~. ,data=swiss)
summary(model)


## (=p-value 0.05) 
## p-value


#Fertility Partial F-test
model_simple<-lm(Infant.Mortality~Fertility ,data=swiss)
anova(model, model_simple)

# predict Fertility Infant.Mortality
new_Fertility<-rnorm(10, mean=mean(swiss$Fertility), sd=sd(swiss$Fertility))
new_Fertility<-as.data.frame(new_Fertility)
colnames(new_Fertility)<-c("Fertility")
predict(model_simple, new_Fertility, interval="prediction")

# For multicolliernarity, use VIF (If vif >4, we have culticollernarity)
require(car)
vif(model)



#2.

# Anova - comparing means of many different groups
analysis<-aov(Sepal.Width~Species, data=iris)
summary(analysis)

# check homogeneity of variances
bartlett.test(Sepal.Width~Species, data=iris)





#3.k-Means Clustering

# Data preparation
require(caret)
set.seed(123)
inTrain <- createDataPartition(y=iris$Species, p=0.7, list=FALSE)
training <- iris[inTrain,]
testing <- iris[-inTrain,]

# Scale it
training.data <- scale(training[-5])
summary(training.data)

iris.kmeans <- kmeans(training.data[,-5], centers = 3, iter.max = 10000)
iris.kmeans$centers
iris.kmeans

#assign the result to training set
training$cluster <- as.factor(iris.kmeans$cluster)
qplot(Petal.Width,Petal.Length,colour=cluster,data=training)

table(training$Species, training$cluster)
## good on Setosa only


## IMPORTANT!!!
## HOW TO DECIDE THE NUMBER OF CLUSTERS?
require(NbClust)

nc <- NbClust(training.data, min.nc=2, max.nc=15, method="kmeans")
par(mfrow=c(1,1))
barplot(table(nc$Best.n[1,]),
        xlab="Numer of Clusters", ylab="Number of Criteria",
        main="Number of Clusters Chosen")

# Make prediction model with training set and predict with test set
training.data<-as.data.frame(training.data)
modFit <- train(x=training.data[,-5],
                y=training$cluster,
                method="rpart")

testing.data<-as.data.frame(scale(testing[-5]))
testClusterPred <- predict(modFit,testing.data)
table(testClusterPred ,testing$Species)
## same with traning result,, good at only Setosa..




## 4. Logistic Regression
data <- read.csv("https://stats.idre.ucla.edu/stat/data/binary.csv")

# Change necessary variables into factors
data$rank <-as.factor(data$rank)

#	Use glm for logistic regression
train<-data[1:200, ]
test<-data[201:400, ]
model <- glm(admit ~ gre + gpa + rank, data =train, family = "binomial")
summary(model)

# CIs using standard errors
confint.default(model)

# Chisq test statistics
anova(model, test="Chisq")

# Interpret "summary(model)"
exp(coef(model))
# for a one unit increase in gpa, 
# the odds of being admitted to graduate school (versus not being admitted) increase by a factor of 1.53

# R-squared in logistic regression
require(pscl)
# look at R-squred at the very last
pR2(model)


# ?????? ??????
# ROC ?????? ????????? ?????? AUC??? 1??? ????????? ?????? ????????? ?????? ???????????? ????????? ??? ??? ??????.
require(ROCR)
p <- predict(model, newdata=test, type="response")
pr <- prediction(p, test$admit)
prf <- performance(pr, measure = "tpr", x.measure = "fpr")
# sensitivity (true positive rate)
plot(prf)
# In this case, if we can only accept a FPR of 20%,
# the model is only giving 35% sensitivity (TPR) at 20% FPR (1-specificity).




#ROC ????????? 2??? ????????? ?????? ?????? AUC??? ??????????????????,
#?????? case??? ????????? ???????????? ???????????? ????????? ?????? AUC??? 1,  
#???????????? ????????? ????????? ?????? ?????? ?????? ?????? (=reference line) AUC??? 0.5??? ?????? ????????? ?????????.

#AUC??? ???????????? ???????????? ????????? ????????? ????????????.
# excellent =  0.9~1
# good = 0.8~0.9
# fair = 0.7~0.8
# poor = 0.6~0.7
# fail = 0.5~0.6

auc_perf <- performance(pr, measure = "auc")
auc <- auc_perf@y.values[[1]]
auc


## Accuary
acc <- performance(pr, measure = "acc");acc
plot(acc)

# Find cutoff point and corresponding accuracy
acc_perf <- performance(pr, measure = "acc")
plot(acc_perf)

# find best accuracy
ind <- which.max(acc_perf@y.values[[1]])

best_acc <- acc_perf@y.values[[1]][ind]
best_cutoff <- acc_perf@x.values[[1]][ind]

c(accuracy = best_acc, cutoff = best_cutoff)


## Zeallot
require(zeallot)
c(x, y) %<-% c(0, 1)
x; y




